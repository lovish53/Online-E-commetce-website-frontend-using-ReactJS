import {BrowserRouter as Router,Route,Routes} from 'react-router-dom'
import Header from "./Header";
import Footer from './Footer';
import Mid from './Mid';
import Men from './Men';
import Women from './Women';
import Kids from './Kids';
function App() {
  return (
    <>
    <Router>
    <Header/>
    <Routes>
      <Route path='/' element={<Mid/>}></Route>
      <Route path='/categories/men' element={<Men/>}></Route>
      <Route path='/categories/women' element={<Women/>}></Route>
      <Route path='/categories/kids' element={<Kids/>}></Route>
    </Routes>
    <Footer/>
    </Router>
    </>
  );
}

export default App;

