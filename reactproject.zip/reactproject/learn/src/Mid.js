import AbsoluteBox from "./Absolute-box";
import Slider from "./Slider";
import Cards from "./Cards";

function Mid() {
    return ( 
        <>
        <Slider />
        <AbsoluteBox />
        <Cards />
        </>
     );
}

export default Mid;