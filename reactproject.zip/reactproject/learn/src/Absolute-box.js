import { Link } from "react-router-dom";

function AbsoluteBox() {
    return ( 
        <section id="absolute-box">
      <div className="container">
        <div className="row">
          <div className="col-md-4">
          <Link to="/categories/women"> <img src="media/women.jpeg" alt="" className="img-fluid" /></Link> 
          <h5>Women</h5>
          </div>
          <div className="col-md-4">
           <Link to="/categories/men"> <img src="media/men1.jpg" alt="" className="img-fluid" /></Link>
           <h5>Men</h5>
          </div>
          <div className="col-md-4">
            <Link to="/categories/kids"><img src="media/pexels-bess-hamiti-35537.jpg" alt="" className="img-fluid" /></Link>
            <h5>Kids</h5>
          </div>
        </div>
        </div>
     </section>
     );
}

export default AbsoluteBox;