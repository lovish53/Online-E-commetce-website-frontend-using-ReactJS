
function Footer() {
  function hide(e){
    document.getElementById("scroll-button").style.height='0px'
    document.getElementById("scroll-button").style.width='0px'
    document.getElementById("scroll-button").style.fontSize='0px'
    document.getElementById("scroll-button").style.border='none'
    document.getElementById("scroll-button").attributes[1].value=''
  }
    return (  
        <section id="footer">
       <div class="container">
        <div class="row">
            <div class="col-md-4 pt-5">
             <img src="media/logo.png" alt="" id="logo-img" class="img-fluid" />
             <p id="footer-p">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Laboriosam impedit voluptates neque deleniti labore at minus asperiores laudantium dolorem, saepe amet esse delectus hic ratione blanditiis eius sed culpa assumenda dolore magni accusamus ipsum aperiam facilis itaque? Iste iusto, ab delectus nobis laudantium nihil enim dolorem assumenda atque iure magnam.</p>
            
            </div>
            <div class="col-md-4  pt-5 ">
                <h2>INDIGO PVT LTD</h2>
                <table class="mt-3">
              <tr><td><i class="bi bi-buildings-fill"></i></td>
                <td>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consectetur repellat facilis quam numquam maxime error</td></tr>
              <tr><td><i class="bi bi-phone-fill"></i></td>
                <td>6283675354,9465512336</td></tr>
              <tr><td><i class="bi bi-telephone-fill"></i></td>
                <td>1438822243</td></tr>
            </table>
            </div>
            <div class="col-md-4  pt-5">
                <h2>QUERRY</h2>
                <form action="" method="post">
                    <input type="email" class="form-control mt-4" placeholder="Enter E-mail" />
                    <textarea name="" id="" class="form-control mt-2 mb-2" placeholder="Enter Querry"></textarea>
                    <button type="submit" class="form-control btn btn-danger ">Post</button>
                </form>
            </div>
        </div>
       </div>
       <div class="container">
          <div class="row text-center">
            <div class="col-md-12 mb-3">
              <img src="media/instagram-icon.png" alt="" class="img-fluid" />
              <img src="media/twitter-icon.png" alt="" class="img-fluid" />
              <img src="media/snapchat-icon.png" alt="" class="img-fluid" />
              <img src="media/linkedin-icon.png" alt="" class="img-fluid" />
            </div>
          </div>
        </div>
       <a href="#header" onClick={(e)=>{hide(e)}}><button id="scroll-button" class=""><i class="bi bi-arrow-up"></i></button></a> 
        
    </section>
    );
}

export default Footer;