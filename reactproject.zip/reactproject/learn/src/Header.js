import { Link } from 'react-router-dom'

function Header() {
    return ( 
        <section id="header">
        <div className="container">
          <div className="row">
            <div className="col-md-12">  
               <nav className="navbar navbar-expand-lg navbar-light">
              <Link className="navbar-brand" to="/">
                <img src="media/logo.png" className="img-fluid" alt="" />
              </Link>
              <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <form className=" d-flex mx-auto w-50" >
                  <input className="form-control" type="search" placeholder="Search" aria-label="Search" id="header-search" />
                  <button className="btn btn-outline-dark bg-success" type="submit" >Search</button>
                </form>
                <Link to="/" ><i className="bi bi-suit-heart-fill"></i></Link> 
                <Link to="/"><i className="bi bi-person"></i></Link>
            </div>
               </nav>
              </div>
               </div>
              </div> 
            <div className="container">
                <div className="row">
                    <div className="col-md-12 ">
                      <nav className="navbar navbar-expand-lg navbar-light">
                        <div className="container-fluid">
                          <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                              <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to="/">Home</Link>
                              </li>
                              <li className="nav-item">
                                <a className="nav-link active" aria-current="page" href="/#cards">Trends</a>
                              </li>
                              <li className="nav-item">
                                <a className="nav-link active" aria-current="page" href="#footer">Contact</a>
                              </li>
                              <li className="nav-item dropdown">
                                <Link className="nav-link dropdown-toggle" to="/" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                 Categories
                                </Link>
                                <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                                  <li><Link className="dropdown-item" to="/categories/men">Men Wear</Link></li>
                                  <li><Link className="dropdown-item" to="/categories/women">Women wear</Link></li>
                                  <li><Link className="dropdown-item" to="/categories/kids">Kid wear</Link></li>
                                </ul>
                              </li>
                              <li className="nav-item dropdown">
                                <Link className="nav-link dropdown-toggle" to="/" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                  Dropdown
                                </Link>
                                <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                                  <li><Link className="dropdown-item" to="/">Action</Link></li>
                                  <li><Link className="dropdown-item" to="/">Another action</Link></li>
                                  <li><hr className="dropdown-divider" /></li>
                                  <li><Link className="dropdown-item" to="/">Something else here</Link></li>
                                </ul>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </nav>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Header;