import { Link } from "react-router-dom";

function Cards() {
    return ( 
        <section id="cards">
        <h2>TRENDS</h2>
        <div className="container">
          <div className="row">
            <div className="col-md-3">
              <div className="card" style={{width: "250px;"}}>
              <img src="media/depositphotos_58764681-stock-photo-young-woman-choosing-clothes-on.jpg" className="card-img-top mx-auto img-fluid" alt="..." />
              <div className="card-body">
                <h5 className="card-title">Card title</h5>
                <Link to="/" className="btn btn-primary">Buy Now</Link>
                <p id="price">$100</p>
                <p id="discount">$99</p>
              </div>
            </div>
          </div>
            <div className="col-md-3">
              <div className="card" style={{width: "250px;"}}>
              <img src="media/efd94113852091.562790f4bc406.jpg" className="card-img-top mx-auto img-fluid" alt="..." />
              <div className="card-body">
                <h5 className="card-title">Card title</h5>
                <Link to="/" className="btn btn-primary">Buy Now</Link>
                <p id="price">$100</p>
                <p id="discount">$99</p>
              </div>
            </div>
          </div>
            <div className="col-md-3">
              <div className="card" style={{width: "250px;"}}>
              <img src="media/depositphotos_97945394-stock-photo-grey-hoody-hanging.jpg " className="card-img-top mx-auto img-fluid" alt="..." />
              <div className="card-body">
                <h5 className="card-title">Card title</h5>
                <Link to="/" className="btn btn-primary">Buy Now</Link>
                <p id="price">$100</p>
                <p id="discount">$99</p>
              </div>
            </div>
          </div>
            <div className="col-md-3">
              <div className="card" style={{width: "250px;"}}>
              <img src="media/men2.webp" className="card-img-top mx-auto img-fluid" alt="..." />
              <div className="card-body">
                <h5 className="card-title">Card title</h5>
                <Link to="/" className="btn btn-primary">Buy Now</Link>
                <p id="price">$100</p>
                <p id="discount">$99</p>
              </div>
            </div>
          </div>
          </div>
        </div>
       </section>
     );
}

export default Cards;