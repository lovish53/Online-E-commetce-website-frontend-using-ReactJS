import { Link } from "react-router-dom";

function Slider() {
    return ( 
        <section id="slider">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-12 pe-0 ps-0">
              <div id="carouselExampleCaptions" className="carousel slide" data-bs-ride="carousel">
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <img src="media/19e7dc45142595.5827f73e99149.jpg" className="d-block img-fluid" alt="..." />
                    <div className="carousel-caption">
                      <Link to="/"><button className="btn btn-danger" id="img1-button">Shop now</button></Link>
                    </div>
                  </div>
                  <div className="carousel-item">
                    <img src="media/photo-1540221652346-e5dd6b50f3e7.jpeg" className="d-block img-fluid" alt="..." />
                  </div>
                  <div className="carousel-item">
                    <img src="media/glass-woman.jpg" className="d-block img-fluid" alt="..." />
                    <div className="carousel-caption">
                      <h3>UNIQUE FASHION</h3>
                      <p>Amazing Deals,Best offers are availabe here</p>
                      <Link to="/"><button className="btn btn-danger ">Shop now</button></Link>
                    </div>
                  </div>
                </div>
                <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                  <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span className="visually-hidden">Previous</span>
                </button>
                <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                  <span className="carousel-control-next-icon" aria-hidden="true"></span>
                  <span className="visually-hidden">Next</span>
                </button>
              </div>
            </div>
          </div>
        </div>
  
      </section>
     );
}

export default Slider;